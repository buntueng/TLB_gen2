from machine import Pin
import time

dt = input("Hello")
print(dt)
print("OK")




